class __init__(object):
    """description of class"""


